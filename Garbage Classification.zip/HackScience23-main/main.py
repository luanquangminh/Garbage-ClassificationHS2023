from threading import Thread
import gui
import text_to_speech
import image

def main():
    gui.main()

if __name__ == '__main__':
    main()